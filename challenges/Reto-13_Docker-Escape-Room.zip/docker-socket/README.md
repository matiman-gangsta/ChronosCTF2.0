# Docker Escape Room

**Categoría:** Cloud
**Dificultad:** Media
**Puntos:** 300

## Descripción

Tienes acceso SSH a un contenedor con un usuario sin privilegios elevados.
Dentro del contenedor hay un socket de Docker expuesto con permisos
demasiado abiertos. Tu objetivo es usar ese socket para escapar del
contenedor y leer una bandera ubicada fuera de él.

```
ssh ctfuser@<host> -p 2222
```

Contraseña: `ctf_docker_2024`

## Despliegue (para quien monte el reto)

Este reto usa **Docker-in-Docker (dind)** para simular el "host" real de
forma aislada. Esto es intencional: así, quien despliega el reto en un
servidor, la escalada del jugador queda contenida dentro del contenedor
`docker-host` (simulado) y **no** compromete el servidor físico real.

```bash
docker-compose up -d --build
```

Esto levanta dos contenedores:

- `docker-host`: simula el "host" que corre el daemon de Docker (dind,
  modo `privileged`). Contiene la bandera en `/root/flag.txt`.
- `challenge`: contenedor accesible por SSH (puerto `2222`) desde el que
  el jugador debe realizar la escalada.

**Requisito importante:** el contenedor `docker-host` necesita salida a
internet para poder descargar la imagen `alpine` (unos 5 MB) en el momento
en que el jugador la usa para montar el volumen y leer la bandera. Si el
entorno de despliegue no tiene salida a internet, hay que precargar la
imagen `alpine` dentro de `docker-host` antes de la competencia (por
ejemplo, con `docker exec ctf-docker-host docker pull alpine` una vez
levantado el stack).

⚠️ **Antes de usar este reto en producción**: pruébalo localmente primero
con `docker-compose up -d --build`, conéctate por SSH y sigue los pasos
de `solution/solution.md` para confirmar que la bandera se obtiene
correctamente. No se pudo validar el arranque completo de Docker-en-Docker
en el entorno donde se generó este reto (sin daemon Docker disponible), así
que esta verificación manual es el paso pendiente más importante.

## Validación automática

```bash
./solve.sh <host> <puerto>
# ej: ./solve.sh localhost 2222
```

Requiere tener `sshpass` instalado en la máquina que ejecuta el script.

## Formato de la bandera

`FLAG{...}`
