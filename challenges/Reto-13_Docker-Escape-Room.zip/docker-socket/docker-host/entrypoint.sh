#!/bin/sh
# Entrypoint del contenedor "docker-host" (simula el host que corre el
# daemon de Docker). Usa Docker-in-Docker (dind) para que la escalada del
# jugador quede contenida dentro de este contenedor y NO comprometa el
# host real de quien despliegue el reto.
set -e

# Arranca dockerd, exponiendo el socket estandar y una copia dentro del
# volumen compartido para que el contenedor "challenge" pueda alcanzarlo.
dockerd-entrypoint.sh \
    --host=unix:///var/run/docker.sock \
    --host=unix:///var/run/docker-shared/docker.sock \
    --storage-driver=vfs &
DOCKERD_PID=$!

# Espera a que el socket compartido exista y luego relaja sus permisos.
# Esto simula la vulnerabilidad real del reto: un socket de Docker expuesto
# con permisos demasiado abiertos, alcanzable por un usuario sin privilegios
# dentro del contenedor "challenge".
i=0
while [ "$i" -lt 60 ]; do
    if [ -S /var/run/docker-shared/docker.sock ]; then
        chmod 666 /var/run/docker-shared/docker.sock
        echo "[docker-host] Socket expuesto en /var/run/docker-shared/docker.sock (modo 666)"
        break
    fi
    i=$((i + 1))
    sleep 1
done

wait "$DOCKERD_PID"
