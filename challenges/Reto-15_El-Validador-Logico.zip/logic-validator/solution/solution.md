# Solución — El Validador Lógico

## 1. Reconocimiento inicial

Al ejecutar el binario sin argumentos:

```
$ ./validator
Uso: ./validator <clave>
```

Con una clave cualquiera:

```
$ ./validator prueba123
[-] Clave incorrecta.
```

## 2. Análisis estático en Ghidra

Al cargar `validator` en Ghidra y descompilar `main`, se observa que:

1. El programa exige `argc >= 2` (la clave se pasa como argumento).
2. Llama a `check_key(argv[1])`.
3. Si `check_key` retorna distinto de 0, llama a `decode_and_print_flag(argv[1])`.

Descompilando `check_key`:

```c
int check_key(const char *input) {
    size_t len = strlen(input);
    if (len != sizeof(target))      // target tiene 16 bytes
        return 0;
    for (size_t i = 0; i < len; i++) {
        unsigned char c = (unsigned char)input[i];
        unsigned char x = c ^ 0x5A;                     // XOR con byte fijo
        unsigned char r = rotl8(x, (i % 4) + 1);         // rotación variable
        if (r != target[i])
            return 0;
    }
    return 1;
}
```

Y `rotl8`:

```c
unsigned char rotl8(unsigned char v, int r) {
    r %= 8;
    return (v << r) | (v >> (8 - r));
}
```

El arreglo `target[]` (visible en la sección `.data`, revisable con
`objdump -s -j .data validator` o directamente en Ghidra) contiene 16 bytes,
lo cual indica que la clave correcta tiene exactamente 16 caracteres.

## 3. Inversión del algoritmo

Para cada posición `i`, se cumple:

```
r = rotl8(c ^ 0x5A, (i % 4) + 1)
```

Para invertir:

```
x = rotr8(r, (i % 4) + 1)      # rotación inversa
c = x ^ 0x5A                    # el XOR es su propia inversa
```

Esto se implementa en `solve.py` (incluido en la raíz del reto), que
reconstruye la clave carácter por carácter sin necesidad de conocerla de
antemano.

## 4. Obtención de la bandera

Una vez reconstruida la clave (`Xor_Rotate_Key99`), se ejecuta:

```
$ ./validator Xor_Rotate_Key99
[+] Clave valida. Acceso concedido.
[+] Bandera: FLAG{ghidra_decompiled_keygen_ok_1647}
```

La bandera se obtiene descifrando `enc_flag[]` (también en `.data`) mediante
XOR repitiendo la clave como stream — la misma lógica que un keystream de
cifrado de flujo simple. Esto impide obtener la bandera únicamente con
`strings` o leyendo constantes: es necesario resolver la clave primero.

## 5. Verificación automática

Ejecutar desde la raíz del reto:

```bash
python3 solve.py --binary ./dist/validator
```

Salida esperada: el script reconstruye la clave de forma independiente,
ejecuta el binario, extrae la bandera de la salida y la compara contra la
esperada, terminando con código de salida 0 si coincide.

## Bandera

```
FLAG{ghidra_decompiled_keygen_ok_1647}
```
