# El Validador Lógico

**Categoría:** Reversing
**Dificultad:** Media
**Puntos:** 250

## Descripción

Se te entrega un binario en C (`dist/validator`) que solicita una clave por
línea de comandos:

```bash
./validator <clave>
```

Internamente valida la clave mediante operaciones lógicas (XOR y rotaciones
de bits). Si la clave es correcta, el binario revela la bandera. Si es
incorrecta, informa el fallo sin dar más pistas.

## Objetivo

1. Descarga y analiza `dist/validator` con Ghidra (o tu desensamblador
   preferido).
2. Ubica la función que valida la clave (revisa el flujo desde `main`).
3. Identifica el algoritmo de transformación aplicado a cada carácter de la
   entrada y los bytes objetivo con los que se compara.
4. Invierte el algoritmo (escribe un "keygen") para reconstruir la clave
   original.
5. Ejecuta el binario con la clave reconstruida para obtener la bandera.

## Entrega

- Solo se entrega el binario `dist/validator`. El código fuente **no** se
  incluye para el jugador (está en `solution/` únicamente para fines de
  corrección).

## Formato de la bandera

`FLAG{...}`
