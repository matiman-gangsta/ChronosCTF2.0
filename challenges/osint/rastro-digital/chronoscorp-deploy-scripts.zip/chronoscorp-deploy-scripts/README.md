# deploy-scripts

scripts de deploy para los microservicios de chronoscorp

uso:
./deploy.sh <entorno>

nota: config.yaml se saco del repo por tener credenciales. usar config.yaml.example
