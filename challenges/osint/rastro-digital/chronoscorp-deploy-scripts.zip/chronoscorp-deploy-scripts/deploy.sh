#!/bin/bash
echo "Deploying chronoscorp services..."
echo "env: $1"
