def health_check():
    return {"status": "ok"}


def ping():
    return True
